//
//  Albums.swift
//  BostaTask
//
//  Created by Aya Mohamed Ahmed on 08/09/2023.
//

import Foundation

// MARK: - Album
struct Album: Codable {
    let id: Int?
    let title: String?
}

